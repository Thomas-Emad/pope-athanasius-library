<div class="bg-brown-max">
    <div class="italic py-2 px-6 text-white flex flex-col md:flex-row items-center justify-between gap-2 font-bold">
        <p class="text-center">
            جميع الحقوق محفوظة لكنيسة الشهيد العظيم مارمينا والبابا كيرلس السادس بالخصوص.
        </p>
        <div>
            <a href="https://www.facebook.com/subdeaconwael" target="__blank"
                class="inline-block text-md py-1 px-3 border border-white hover:border-gray-800 hover:text-gray-800 rounded-lg duration-200">
                <i class="fa-brands fa-facebook"></i>
            </a>
            <a href="https://www.facebook.com/m.marmina/" target="__blank"
                class="inline-block text-md  py-1 px-3  border border-white hover:border-gray-800 hover:text-gray-800 rounded-lg duration-200">
                <i class="fa-solid fa-church"></i>
            </a>
            <a href="mailto:thomas@gmail.com"
                class="inline-block text-md  py-1 px-3 border border-white hover:border-gray-800 hover:text-gray-800 rounded-lg duration-200">
                <i class="fa-solid fa-envelope"></i>
            </a>
            <a href="https://maps.app.goo.gl/LTo4Y6XrxH6hqMSF6" target="__blank"
                class="inline-block text-md  py-1 px-3  border border-white hover:border-gray-800 hover:text-gray-800 rounded-lg duration-200">
                <i class="fa-solid fa-map-location-dot"></i>
            </a>
        </div>
    </div>
</div>
