<div>
    <x-modals.author-modal />
</div>
