<div>
    <x-modals.publisher-modal />
</div>
