<?php

return [
  App\Providers\AppServiceProvider::class,
  App\Providers\VoltServiceProvider::class,
  Maatwebsite\Excel\ExcelServiceProvider::class,
];
